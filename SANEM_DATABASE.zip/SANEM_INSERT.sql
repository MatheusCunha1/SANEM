INSERT INTO usuario (nome, email, senha_hash, tipo) VALUES
('Jo�o Silva', 'joao.silva@sanem.org', '$2b$10$XYZ...HashDaSenha...', 'Administrador'),
('Maria Santos', 'maria.santos@sanem.org', '$2b$10$ABC...HashDaSenha...', 'Operador'),
('Carlos Oliveira', 'carlos.oliveira@sanem.org', '$2b$10$DEF...HashDaSenha...', 'Operador');

INSERT INTO categoria (nome, descricao, unidade_medida) VALUES
('Alimentos N�o Perec�veis', 'Arroz, feij�o, macarr�o, �leo, etc.', 'kg'),
('Alimentos Perec�veis', 'Frutas, verduras, carnes, latic�nios', 'kg'),
('Roupas', 'Vestu�rio em geral', 'unidade'),
('Cal�ados', 'Sapatos, t�nis, chinelos', 'par'),
('Produtos de Higiene', 'Sabonete, xampu, pasta de dente, etc.', 'unidade'),
('Produtos de Limpeza', 'Detergente, sab�o em p�, desinfetante', 'unidade'),
('Brinquedos', 'Brinquedos para crian�as', 'unidade'),
('Material Escolar', 'Cadernos, l�pis, canetas, mochilas', 'unidade');

INSERT INTO item (id_categoria, nome, descricao, quantidade_estoque, estoque_minimo) VALUES
(1, 'Arroz tipo 1', 'Arroz branco tipo 1, pacote de 5kg', 150.00, 50.00),
(1, 'Feij�o carioca', 'Feij�o carioca, pacote de 1kg', 80.00, 30.00),
(1, 'Macarr�o espaguete', 'Macarr�o espaguete 500g', 120.00, 40.00),
(1, '�leo de soja', '�leo de soja 900ml', 60.00, 20.00),
(1, 'A��car cristal', 'A��car cristal 1kg', 45.00, 20.00),
(1, 'Caf� em p�', 'Caf� em p� 500g', 35.00, 15.00),
(1, 'Sal refinado', 'Sal refinado 1kg', 40.00, 15.00),
(1, 'Farinha de trigo', 'Farinha de trigo 1kg', 55.00, 20.00),
(2, 'Leite integral', 'Leite integral 1L', 30.00, 10.00),
(2, 'Carne mo�da', 'Carne mo�da bovina', 15.00, 5.00),
(3, 'Camiseta adulto M', 'Camiseta b�sica tamanho M', 25.00, 10.00),
(3, 'Cal�a jeans adulto', 'Cal�a jeans diversos tamanhos', 18.00, 8.00),
(3, 'Roupa infantil 2-4 anos', 'Conjuntos infantis variados', 30.00, 10.00),
(4, 'Chinelo adulto', 'Chinelo de borracha tamanhos variados', 22.00, 10.00),
(4, 'T�nis infantil', 'T�nis diversos tamanhos', 15.00, 5.00),
(5, 'Sabonete', 'Sabonete em barra 90g', 100.00, 40.00),
(5, 'Xampu', 'Xampu 350ml', 45.00, 20.00),
(5, 'Pasta de dente', 'Creme dental 90g', 60.00, 25.00),
(5, 'Papel higi�nico', 'Papel higi�nico 4 rolos', 50.00, 20.00),
(5, 'Absorvente feminino', 'Absorvente com abas', 35.00, 15.00),
(6, 'Detergente', 'Detergente l�quido 500ml', 40.00, 15.00),
(6, 'Sab�o em p�', 'Sab�o em p� 1kg', 30.00, 10.00),
(6, '�gua sanit�ria', '�gua sanit�ria 1L', 28.00, 12.00),
(7, 'Boneca', 'Bonecas diversas', 12.00, 5.00),
(7, 'Carrinho', 'Carrinhos de brinquedo', 10.00, 5.00),
(8, 'Caderno universit�rio', 'Caderno 10 mat�rias', 40.00, 15.00),
(8, 'Estojo completo', 'Estojo com l�pis, canetas e borracha', 25.00, 10.00),
(8, 'Mochila escolar', 'Mochila para estudantes', 18.00, 8.00);

INSERT INTO doador (nome, cpf_cnpj, tipo_pessoa, telefone, email, endereco) VALUES
('Supermercado Bom Pre�o Ltda', '12.345.678/0001-90', 'Jur�dica', '(41) 3333-4444', 'contato@bompreco.com.br', 'Av. Principal, 1000 - Centro - Curitiba/PR'),
('Ana Paula Ferreira', '123.456.789-00', 'F�sica', '(41) 99999-8888', 'ana.paula@email.com', 'Rua das Flores, 234 - Batel - Curitiba/PR'),
('Padaria P�o Quente', '98.765.432/0001-11', 'Jur�dica', '(41) 3232-5656', 'paoquente@gmail.com', 'Rua do Com�rcio, 567 - Agua Verde - Curitiba/PR'),
('Roberto Carlos da Silva', '987.654.321-00', 'F�sica', '(41) 98888-7777', 'roberto.silva@email.com', 'Av. Sete de Setembro, 890 - Centro - Curitiba/PR'),
('Igreja Assembleia de Deus', '11.222.333/0001-44', 'Jur�dica', '(41) 3344-5566', 'assembleia@igreja.org', 'Rua da Paz, 123 - Port�o - Curitiba/PR');

INSERT INTO beneficiario (nome, cpf, telefone, endereco, situacao_social, numero_membros_familia) VALUES
('Joana Maria dos Santos', '111.222.333-44', '(41) 97777-6666', 'Rua Esperan�a, 45 - CIC - Curitiba/PR', 'Desempregada, m�e solteira', 4),
('Pedro Henrique Costa', '222.333.444-55', '(41) 96666-5555', 'Av. das Na��es, 234 - Cajuru - Curitiba/PR', 'Trabalhador informal', 3),
('Francisca Aparecida Lima', '333.444.555-66', '(41) 95555-4444', 'Rua do Sol, 678 - Tatuquara - Curitiba/PR', 'Aposentada por invalidez', 2),
('Jos� Carlos Pereira', '444.555.666-77', '(41) 94444-3333', 'Rua da Alegria, 901 - S�tio Cercado - Curitiba/PR', 'Desempregado', 5),
('Maria das Gra�as Oliveira', '555.666.777-88', '(41) 93333-2222', 'Av. Paran�, 1234 - Pinheirinho - Curitiba/PR', 'Trabalho tempor�rio', 3);

INSERT INTO doacao (id_doador, id_usuario, observacao, valor_estimado) VALUES
(1, 1, 'Doa��o mensal do supermercado - alimentos n�o perec�veis', 1500.00),
(2, 2, 'Doa��o de roupas e cal�ados usados em bom estado', 300.00),
(3, 2, 'Doa��o de p�es e produtos de padaria', 200.00),
(4, 3, 'Doa��o de materiais de higiene e limpeza', 250.00),
(5, 1, 'Doa��o da campanha de Natal - diversos itens', 800.00);

INSERT INTO item_doacao (id_doacao, id_item, quantidade, lote, validade) VALUES
(1, 1, 50.00, 'LOT001', '2027-12-31'),
(1, 2, 30.00, 'LOT002', '2027-10-15'),
(1, 3, 40.00, 'LOT003', '2027-08-20'),
(1, 4, 20.00, 'LOT004', '2026-12-31'),
(2, 11, 10.00, NULL, NULL),
(2, 12, 5.00, NULL, NULL),
(2, 14, 8.00, NULL, NULL),
(3, 9, 15.00, 'LOT005', '2026-04-10'),
(4, 16, 30.00, 'LOT006', '2028-05-15'),
(4, 18, 20.00, 'LOT007', '2027-11-30'),
(4, 21, 15.00, 'LOT008', '2028-01-15'),
(5, 13, 12.00, NULL, NULL),
(5, 24, 8.00, NULL, NULL),
(5, 26, 15.00, NULL, NULL),
(5, 27, 10.00, NULL, NULL);

INSERT INTO distribuicao (id_beneficiario, id_usuario, observacao, status) VALUES
(1, 2, 'Cesta b�sica mensal', 'Conclu�da'),
(2, 2, 'Kit higiene e limpeza', 'Conclu�da'),
(3, 3, 'Cesta b�sica + roupas', 'Conclu�da'),
(4, 2, 'Cesta b�sica mensal', 'Conclu�da'),
(5, 3, 'Kit material escolar + alimentos', 'Conclu�da');

INSERT INTO item_distribuicao (id_distribuicao, id_item, quantidade, lote) VALUES
(1, 1, 10.00, 'LOT001'),
(1, 2, 5.00, 'LOT002'),
(1, 3, 5.00, 'LOT003'),
(1, 4, 2.00, 'LOT004'),
(1, 16, 4.00, 'LOT006'),
(2, 16, 5.00, 'LOT006'),
(2, 18, 3.00, 'LOT007'),
(2, 21, 2.00, 'LOT008'),
(3, 1, 5.00, 'LOT001'),
(3, 2, 3.00, 'LOT002'),
(3, 11, 3.00, NULL),
(4, 1, 15.00, 'LOT001'),
(4, 2, 8.00, 'LOT002'),
(4, 3, 8.00, 'LOT003'),
(5, 1, 8.00, 'LOT001'),
(5, 26, 5.00, NULL),
(5, 27, 3.00, NULL);